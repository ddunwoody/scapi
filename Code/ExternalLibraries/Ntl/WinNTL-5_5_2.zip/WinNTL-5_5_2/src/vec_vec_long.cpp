
#include <NTL/vec_vec_long.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(vec_long,vec_vec_long)

NTL_eq_vector_impl(vec_long,vec_vec_long)

NTL_io_vector_impl(vec_long,vec_vec_long)


NTL_END_IMPL
