
#include <NTL/vec_quad_float.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(quad_float,vec_quad_float)

NTL_io_vector_impl(quad_float,vec_quad_float)

NTL_eq_vector_impl(quad_float,vec_quad_float)

NTL_END_IMPL

