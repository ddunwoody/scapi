
#include <NTL/vec_GF2XVec.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(GF2XVec,vec_GF2XVec)

NTL_END_IMPL
