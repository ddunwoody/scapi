[ "`echo 12345 u | ./factor 54321`" = "12345 5 p2f" ]
